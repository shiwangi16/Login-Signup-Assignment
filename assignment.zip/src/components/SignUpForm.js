import React from "react";
import "./SignUpForm.css";

const LoginForm = () => {
  return (
    <div className="form1">
        <br />
      <h1 className="head1">Sign Up</h1>
      <form className="LoginForm">
        <div>
          <input
            type="name"
            placeholder="Name"
            className="field1"
            id="exampleNameEmail1"
          />
        </div>
        <br />
        <div>
          <input
            type="email"
            placeholder="Enter your email"
            className="field1"
            id="exampleInputEmail1"
          />
        </div>
        <br />
        <div>
          <input
            type="password"
            placeholder="Enter your password"
            className="field1"
            id="exampleInputPassword1"
          />
        </div>
        <br />
        <button type="submit" className="btn">Sign Up</button>
        <br />
        <br />
        <button type="submit" className="btn">Login as Guest User</button>
      </form>
      <br />
      <p>
        Have an account{" "}
        <a href="/signIn" className="anchor">
          <b>SignIn Now.</b>
        </a>
      </p>
    </div>
  );
};

export default LoginForm;
