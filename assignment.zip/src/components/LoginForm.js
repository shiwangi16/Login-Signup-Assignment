import React from "react";
import "./LoginForm.css";

const LoginForm = () => {
  return (
    <div className="form1">
        <br />
      <h1 className="head1">Sign In</h1>
      <form className="LoginForm">
        <div>
          <input
            type="email"
            placeholder="Enter your email"
            className="field1"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
          />
        </div>
        <br />
        <div>
          <input
            type="password"
            placeholder="Enter your password"
            className="field1"
            id="exampleInputPassword1"
          />
        </div>
        <br />
        <button type="submit" className="btn">Sign In</button>
        <br />
        <br />
        <button type="submit" className="btn">Login as Guest User</button>
      </form>
      <br />
      <p>
        New to MovieApp?{" "}
        <a href="/signup" className="anchor">
          <b>SignUp Now.</b>
        </a>
      </p>
    </div>
  );
};

export default LoginForm;
